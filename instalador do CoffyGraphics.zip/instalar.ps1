# =======================================================================
# INSTALADOR AUTO-GERADOR DO COFFYGRAPHICS (POWERSHELL)
# =======================================================================

$targetDir = "$env:USERPROFILE\CoffyGraphics"
Write-Host "==========================================================" -ForegroundColor Yellow
Write-Host "   Instalando CoffyGraphics do Zero em: $targetDir" -ForegroundColor Yellow
Write-Host "=========================================================="
Write-Host ""

function Write-ProjectFile {
    param (
        [string]$RelativePath,
        [string]$Content
    )
    $fullPath = Join-Path -Path $targetDir -ChildPath $RelativePath
    $parentDir = Split-Path -Path $fullPath -Parent
    if (-not (Test-Path -Path $parentDir)) {
        New-Item -ItemType Directory -Force -Path $parentDir | Out-Null
    }
    [System.IO.File]::WriteAllText($fullPath, $Content, [System.Text.Encoding]::UTF8)
    Write-Host " Gerado: $RelativePath" -ForegroundColor Green
}

# -----------------------------------------------------------------------
# 1. pom.xml
# -----------------------------------------------------------------------
$pomXml = @(
'<project xmlns="http://maven.apache.org/POM/4.0.0"',
'         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"',
'         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">',
'    <modelVersion>4.0.0</modelVersion>',
'',
'    <groupId>com.coffygraphics</groupId>',
'    <artifactId>CoffyGraphics</artifactId>',
'    <version>0.1.0</version>',
'    <packaging>jar</packaging>',
'',
'    <properties>',
'        <maven.compiler.source>17</maven.compiler.source>',
'        <maven.compiler.target>17</maven.compiler.target>',
'        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>',
'        <javafx.version>21</javafx.version>',
'    </properties>',
'',
'    <dependencies>',
'        <dependency>',
'            <groupId>org.openjfx</groupId>',
'            <artifactId>javafx-controls</artifactId>',
'            <version>${javafx.version}</version>',
'        </dependency>',
'        <dependency>',
'            <groupId>org.openjfx</groupId>',
'            <artifactId>javafx-fxml</artifactId>',
'            <version>${javafx.version}</version>',
'        </dependency>',
'        <dependency>',
'            <groupId>org.fxmisc.richtext</groupId>',
'            <artifactId>richtextfx</artifactId>',
'            <version>0.11.0</version>',
'        </dependency>',
'        <dependency>',
'            <groupId>com.github.javaparser</groupId>',
'            <artifactId>javaparser-core</artifactId>',
'            <version>3.25.8</version>',
'        </dependency>',
'    </dependencies>',
'',
'    <build>',
'        <plugins>',
'            <plugin>',
'                <groupId>org.apache.maven.plugins</groupId>',
'                <artifactId>maven-compiler-plugin</artifactId>',
'                <version>3.11.0</version>',
'                <configuration>',
'                    <source>17</source>',
'                    <target>17</target>',
'                </configuration>',
'            </plugin>',
'            <plugin>',
'                <groupId>org.openjfx</groupId>',
'                <artifactId>javafx-maven-plugin</artifactId>',
'                <version>0.0.8</version>',
'                <configuration>',
'                    <mainClass>com.coffygraphics.Main</mainClass>',
'                </configuration>',
'            </plugin>',
'        </plugins>',
'    </build>',
'</project>'
) -join "`n"
Write-ProjectFile -RelativePath "pom.xml" -Content $pomXml

# -----------------------------------------------------------------------
# 2. Main.java
# -----------------------------------------------------------------------
$mainJava = @(
'package com.coffygraphics;',
'',
'import com.coffygraphics.ui.MainWindow;',
'import javafx.application.Application;',
'import javafx.scene.Scene;',
'import javafx.stage.Stage;',
'',
'public class Main extends Application {',
'    @Override',
'    public void start(Stage primaryStage) {',
'        MainWindow mainWindow = new MainWindow();',
'        Scene scene = new Scene(mainWindow.buildUI(), 1280, 720);',
'        ',
'        String css = getClass().getResource("/com/coffygraphics/coffy.css").toExternalForm();',
'        scene.getStylesheets().add(css);',
'',
'        primaryStage.setTitle("CoffyGraphics v0.1");',
'        primaryStage.setScene(scene);',
'        primaryStage.show();',
'    }',
'',
'    public static void main(String[] args) {',
'        launch(args);',
'    }',
'}'
) -join "`n"
Write-ProjectFile -RelativePath "src/main/java/com/coffygraphics/Main.java" -Content $mainJava

# -----------------------------------------------------------------------
# 3. MainWindow.java
# -----------------------------------------------------------------------
$mainWindowJava = @(
'package com.coffygraphics.ui;',
'',
'import com.coffygraphics.design.DesignCanvas;',
'import com.coffygraphics.core.WorkspaceManager;',
'import com.coffygraphics.core.MavenRunner;',
'import javafx.scene.Parent;',
'import javafx.scene.control.*;',
'import javafx.scene.layout.*;',
'',
'public class MainWindow {',
'    private final DesignCanvas canvas = new DesignCanvas();',
'    private final WorkspaceManager workspaceManager = new WorkspaceManager();',
'',
'    public Parent buildUI() {',
'        BorderPane root = new BorderPane();',
'',
'        MenuBar menuBar = new MenuBar();',
'        Menu menuFile = new Menu("Arquivo");',
'        MenuItem itemSelectWorkspace = new MenuItem("Selecionar Workspace...");',
'        itemSelectWorkspace.setOnAction(e -> workspaceManager.selectWorkspace());',
'        menuFile.getItems().add(itemSelectWorkspace);',
'',
'        Menu menuBuild = new Menu("Executar");',
'        MenuItem itemCompile = new MenuItem("mvn compile");',
'        itemCompile.setOnAction(e -> MavenRunner.runCommand("mvn compile"));',
'        MenuItem itemRun = new MenuItem("mvn exec:java");',
'        itemRun.setOnAction(e -> MavenRunner.runCommand("mvn exec:java"));',
'        menuBuild.getItems().addAll(itemCompile, itemRun);',
'',
'        menuBar.getMenus().addAll(menuFile, menuBuild);',
'        root.setTop(menuBar);',
'',
'        SplitPane centerSplit = new SplitPane();',
'        ',
'        VBox palette = new VBox(10);',
'        palette.setStyle("-fx-padding: 10; -fx-background-color: #f4f4f4;");',
'        palette.getChildren().add(new Label("Paleta de Componentes"));',
'',
'        Button btnAddButton = new Button("Adicionar Botão");',
'        btnAddButton.setOnAction(e -> canvas.addButton("Botão"));',
'        ',
'        Button btnAddLabel = new Button("Adicionar Label");',
'        btnAddLabel.setOnAction(e -> canvas.addLabel("Texto Exemplo"));',
'',
'        palette.getChildren().addAll(btnAddButton, btnAddLabel);',
'',
'        centerSplit.getItems().addAll(palette, canvas.getCanvasPane());',
'        centerSplit.setDividerPositions(0.2);',
'',
'        root.setCenter(centerSplit);',
'',
'        TextArea console = new TextArea();',
'        console.setEditable(false);',
'        console.setPrefHeight(120);',
'        console.setPromptText("Saída do Console Maven...");',
'        root.setBottom(console);',
'',
'        return root;',
'    }',
'}'
) -join "`n"
Write-ProjectFile -RelativePath "src/main/java/com/coffygraphics/ui/MainWindow.java" -Content $mainWindowJava

# -----------------------------------------------------------------------
# 4. DesignCanvas.java
# -----------------------------------------------------------------------
$designCanvasJava = @(
'package com.coffygraphics.design;',
'',
'import javafx.scene.Node;',
'import javafx.scene.control.Button;',
'import javafx.scene.control.Label;',
'import javafx.scene.input.KeyCode;',
'import javafx.scene.layout.Pane;',
'',
'public class DesignCanvas {',
'    private final Pane canvasPane = new Pane();',
'    private Node selectedNode = null;',
'',
'    public DesignCanvas() {',
'        canvasPane.setStyle("-fx-background-color: #ffffff; -fx-border-color: #cccccc;");',
'        ',
'        canvasPane.setFocusTraversable(true);',
'        canvasPane.setOnKeyPressed(e -> {',
'            if (e.getCode() == KeyCode.DELETE && selectedNode != null) {',
'                canvasPane.getChildren().remove(selectedNode);',
'                selectedNode = null;',
'            }',
'        });',
'    }',
'',
'    public Pane getCanvasPane() {',
'        return canvasPane;',
'    }',
'',
'    public void addButton(String text) {',
'        Button btn = ComponentFactory.createButton(text);',
'        makeDraggable(btn);',
'        canvasPane.getChildren().add(btn);',
'    }',
'',
'    public void addLabel(String text) {',
'        Label lbl = ComponentFactory.createLabel(text);',
'        makeDraggable(lbl);',
'        canvasPane.getChildren().add(lbl);',
'    }',
'',
'    private void makeDraggable(Node node) {',
'        final double[] dragDelta = new double[2];',
'',
'        node.setOnMousePressed(me -> {',
'            dragDelta[0] = node.getLayoutX() - me.getSceneX();',
'            dragDelta[1] = node.getLayoutY() - me.getSceneY();',
'            selectedNode = node;',
'            canvasPane.requestFocus();',
'        });',
'',
'        node.setOnMouseDragged(me -> {',
'            node.setLayoutX(me.getSceneX() + dragDelta[0]);',
'            node.setLayoutY(me.getSceneY() + dragDelta[1]);',
'        });',
'    }',
'}'
) -join "`n"
Write-ProjectFile -RelativePath "src/main/java/com/coffygraphics/design/DesignCanvas.java" -Content $designCanvasJava

# -----------------------------------------------------------------------
# 5. BezierEditor.java
# -----------------------------------------------------------------------
$bezierEditorJava = @(
'package com.coffygraphics.design;',
'',
'import javafx.scene.Group;',
'import javafx.scene.paint.Color;',
'import javafx.scene.shape.CubicCurve;',
'',
'public class BezierEditor extends Group {',
'    private final CubicCurve curve = new CubicCurve();',
'',
'    public BezierEditor() {',
'        curve.setStartX(50);',
'        curve.setStartY(100);',
'        curve.setControlX1(150);',
'        curve.setControlY1(50);',
'        curve.setControlX2(250);',
'        curve.setControlY2(150);',
'        curve.setEndX(350);',
'        curve.setEndY(100);',
'',
'        curve.setStroke(Color.BROWNSUIT);',
'        curve.setStrokeWidth(3);',
'        curve.setFill(null);',
'',
'        getChildren().add(curve);',
'    }',
'}'
) -join "`n"
Write-ProjectFile -RelativePath "src/main/java/com/coffygraphics/design/BezierEditor.java" -Content $bezierEditorJava

# -----------------------------------------------------------------------
# 6. ComponentFactory.java
# -----------------------------------------------------------------------
$componentFactoryJava = @(
'package com.coffygraphics.design;',
'',
'import javafx.scene.control.Button;',
'import javafx.scene.control.Label;',
'',
'public class ComponentFactory {',
'    public static Button createButton(String text) {',
'        Button btn = new Button(text);',
'        btn.setStyle("-fx-background-color: #007bff; -fx-text-fill: white; -fx-font-weight: bold;");',
'        return btn;',
'    }',
'',
'    public static Label createLabel(String text) {',
'        Label lbl = new Label(text);',
'        lbl.setStyle("-fx-font-size: 14px; -fx-text-fill: #333333;");',
'        return lbl;',
'    }',
'}'
) -join "`n"
Write-ProjectFile -RelativePath "src/main/java/com/coffygraphics/design/ComponentFactory.java" -Content $componentFactoryJava

# -----------------------------------------------------------------------
# 7. FxmlGenerator.java
# -----------------------------------------------------------------------
$fxmlGeneratorJava = @(
'package com.coffygraphics.codegen;',
'',
'import javafx.scene.Node;',
'import javafx.scene.layout.Pane;',
'',
'public class FxmlGenerator {',
'    public static String generateFxml(Pane canvas) {',
'        StringBuilder sb = new StringBuilder();',
'        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");',
'        sb.append("<?import javafx.scene.layout.Pane?>\n");',
'        sb.append("<Pane xmlns=\"http://javafx.com/javafx/21\" xmlns:fx=\"http://javafx.com/fxml/1\">\n");',
'        sb.append("    <children>\n");',
'',
'        for (Node node : canvas.getChildren()) {',
'            sb.append("        <!-- Componente: ").append(node.getClass().getSimpleName()).append(" -->\n");',
'        }',
'',
'        sb.append("    </children>\n");',
'        sb.append("</Pane>\n");',
'        return sb.toString();',
'    }',
'}'
) -join "`n"
Write-ProjectFile -RelativePath "src/main/java/com/coffygraphics/codegen/FxmlGenerator.java" -Content $fxmlGeneratorJava

# -----------------------------------------------------------------------
# 8. MavenRunner.java
# -----------------------------------------------------------------------
$mavenRunnerJava = @(
'package com.coffygraphics.core;',
'',
'import java.io.BufferedReader;',
'import java.io.InputStreamReader;',
'',
'public class MavenRunner {',
'    public static void runCommand(String command) {',
'        new Thread(() -> {',
'            try {',
'                ProcessBuilder pb = new ProcessBuilder(command.split(" "));',
'                pb.redirectErrorStream(true);',
'                Process p = pb.start();',
'',
'                BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));',
'                String line;',
'                while ((line = reader.readLine()) != null) {',
'                    System.out.println(line);',
'                }',
'            } catch (Exception e) {',
'                e.printStackTrace();',
'            }',
'        }).start();',
'    }',
'}'
) -join "`n"
Write-ProjectFile -RelativePath "src/main/java/com/coffygraphics/core/MavenRunner.java" -Content $mavenRunnerJava

# -----------------------------------------------------------------------
# 9. WorkspaceManager.java
# -----------------------------------------------------------------------
$workspaceManagerJava = @(
'package com.coffygraphics.core;',
'',
'import javafx.stage.DirectoryChooser;',
'import java.io.File;',
'',
'public class WorkspaceManager {',
'    private File currentWorkspace;',
'',
'    public void selectWorkspace() {',
'        DirectoryChooser chooser = new DirectoryChooser();',
'        chooser.setTitle("Selecionar Pasta do Workspace");',
'        File selected = chooser.showDialog(null);',
'        if (selected != null) {',
'            this.currentWorkspace = selected;',
'            System.out.println("Workspace selecionado: " + selected.getAbsolutePath());',
'        }',
'    }',
'',
'    public File getCurrentWorkspace() {',
'        return currentWorkspace;',
'    }',
'}'
) -join "`n"
Write-ProjectFile -RelativePath "src/main/java/com/coffygraphics/core/WorkspaceManager.java" -Content $workspaceManagerJava

# -----------------------------------------------------------------------
# 10. coffy.css
# -----------------------------------------------------------------------
$coffyCss = @(
'.root {',
'    -fx-font-family: "Segoe UI", sans-serif;',
'    -fx-base: #f7f5f0;',
'}',
'',
'.button {',
'    -fx-background-radius: 4;',
'    -fx-cursor: hand;',
'}'
) -join "`n"
Write-ProjectFile -RelativePath "src/main/resources/com/coffygraphics/coffy.css" -Content $coffyCss

# -----------------------------------------------------------------------
# 11. logo.svg
# -----------------------------------------------------------------------
$logoSvg = @(
'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" width="256" height="256">',
'  <rect width="256" height="256" rx="60" fill="#FFF6EB"/>',
'  <path d="M142,60 Q147,70 142,80 T142,100" fill="none" stroke="#B08D79" stroke-width="6" stroke-linecap="round"/>',
'  <path d="M162,60 Q167,70 162,80 T162,100" fill="none" stroke="#B08D79" stroke-width="6" stroke-linecap="round"/>',
'  <path d="M182,60 Q187,70 182,80 T182,100" fill="none" stroke="#B08D79" stroke-width="6" stroke-linecap="round"/>',
'  <path d="M70,110 C70,180 100,200 150,200 C200,200 230,180 230,110 Z" fill="#7C4A32"/>',
'  <path d="M220,125 C245,125 255,140 255,155 C255,170 240,180 220,180" fill="none" stroke="#7C4A32" stroke-width="16" stroke-linecap="round"/>',
'  <circle cx="115" cy="170" r="22" fill="#8D624C" stroke="#1A2332" stroke-width="8"/>',
'  <circle cx="175" cy="170" r="22" fill="#8D624C" stroke="#1A2332" stroke-width="8"/>',
'  <path d="M137,165 Q145,160 153,165" fill="none" stroke="#1A2332" stroke-width="7" stroke-linecap="round"/>',
'  <line x1="88" y1="160" x2="95" y2="163" stroke="#1A2332" stroke-width="8" stroke-linecap="round"/>',
'  <line x1="195" y1="163" x2="202" y2="160" stroke="#1A2332" stroke-width="8" stroke-linecap="round"/>',
'  <g transform="rotate(-35 200 100)">',
'    <polygon points="180,20 195,20 200,140 175,140" fill="#F59E0B"/>',
'    <polygon points="175,140 200,140 187.5,165" fill="#FDE68A"/>',
'    <polygon points="184,158 191,158 187.5,165" fill="#1E293B"/>',
'    <rect x="175" y="10" width="25" height="10" rx="2" fill="#EC4899"/>',
'  </g>',
'  <rect x="72" y="215" width="136" height="10" rx="5" fill="#D6C0B3"/>',
'</svg>'
) -join "`n"
Write-ProjectFile -RelativePath "src/main/resources/com/coffygraphics/logo.svg" -Content $logoSvg
Write-ProjectFile -RelativePath "docs/logo.svg" -Content $logoSvg

# -----------------------------------------------------------------------
# 12. README.md & PROMPT.md
# -----------------------------------------------------------------------
$readmeMd = @(
'# CoffyGraphics',
'',
'Ambiente visual de prototipagem e design para JavaFX.',
'',
'## Como Executar',
'Execute o arquivo `Executar-CoffyGraphics.bat` ou abra o terminal e rode:',
'```bash',
'mvn javafx:run',
'```'
) -join "`n"
Write-ProjectFile -RelativePath "README.md" -Content $readmeMd

$promptMd = @(
'# CoffyGraphics - Roadmap & Prompts',
'',
'## Fase 1',
'- Canvas Interativo',
'- Componentes Básicos',
'- Gerador FXML',
'',
'## Fase 2',
'- Redimensionamento e Rotação',
'- Editor de Gradientes e Sombras',
'- Integração com JavaParser'
) -join "`n"
Write-ProjectFile -RelativePath "docs/PROMPT.md" -Content $promptMd

# -----------------------------------------------------------------------
# 13. Executável / Script Launcher
# -----------------------------------------------------------------------
$batLauncher = @(
'@echo off',
'title CoffyGraphics Launcher',
'cd /d "%~dp0"',
'echo Iniciando CoffyGraphics...',
'call mvn javafx:run',
'if %ERRORLEVEL% NEQ 0 (',
'    echo.',
'    echo [ERRO] Falha ao rodar com Maven. Verifique se o JDK 17+ e o Maven estao no PATH.',
'    pause',
')'
) -join "`r`n"
Write-ProjectFile -RelativePath "Executar-CoffyGraphics.bat" -Content $batLauncher

# -----------------------------------------------------------------------
# 14. Criar Atalho na Área de Trabalho
# -----------------------------------------------------------------------
$launcherPath = Join-Path -Path $targetDir -ChildPath "Executar-CoffyGraphics.bat"
$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\CoffyGraphics.lnk")
$Shortcut.TargetPath = $launcherPath
$Shortcut.WorkingDirectory = $targetDir
$Shortcut.Save()

Write-Host ""
Write-Host "==========================================================" -ForegroundColor Yellow
Write-Host " [SUCESSO] PROJETO GERADO COMPLETAMENTE DO ZERO!" -ForegroundColor Green
Write-Host " Pasta: $targetDir" -ForegroundColor Cyan
Write-Host " Atalho criado na sua Area de Trabalho!" -ForegroundColor Green
Write-Host "=========================================================="