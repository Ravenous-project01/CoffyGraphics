# ☕✏️👓 CoffyGraphics
IDE Java/Maven com editor visual (estilo Scene Builder + WindowBuilder). **Versão 0.1 (MVP / fundação)**.

## Rodar
Requisitos: JDK 17+, Maven 3.8+ (precisa de internet na 1ª vez para baixar dependências).

    mvn javafx:run

## Já funciona (v0.1)
- Launcher com escolha/memória do Workspace; Explorer lista projetos Maven; novo projeto Maven (pom + src/main|test) e par FXML+Controller
- `mvn compile` / `mvn exec:java` com saída no Console
- Canvas: arrastar da paleta, mover livremente, grid snap, Delete remove
- Modelos de botão (Primário, Perigo, Contorno, Pílula) e label (Título, Subtítulo, Destaque); formas; Curva Bézier editável (alças, duplo clique adiciona segmento, clique direito na âncora remove)
- Inspetor (fx:id, texto, X, Y, style) e barra lateral de código ao vivo (FXML ou Java declarativo)

## Próximos passos
Veja docs/PROMPT.md.
