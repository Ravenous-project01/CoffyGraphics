# CoffyGraphics — Prompt de desenvolvimento (use com qualquer assistente de código)

Atue como arquiteto sênior JavaFX. Evolua o projeto Maven "CoffyGraphics" (Java 17+, JavaFX 21, RichTextFX, JavaParser) para uma IDE Java/Maven com editor visual, em fases, entregando código compilável e testes a cada fase.

## Identidade
Nome CoffyGraphics. Logo: xícara de café com lápis e óculos (docs/logo.svg). Paleta: café #8B5E3C, creme #FBF3E6, âmbar #F59E0B, azul de seleção #3B82F6. Tema claro/escuro.

## Fase 1 — Workspace e Maven
- Launcher pede o Workspace; opção "usar como padrão"; varre pastas com pom.xml.
- Todo projeto novo é Maven (pom, src/main/java, src/main/resources, src/test/java). Wizards: Projeto (groupId/artifactId/version + modelos JavaFX App, CLI, REST client), Pacote, Classe/Interface/Enum (main, construtores), Janela (FXML + Controller pareados).
- Console: mvn compile/exec:java/test/package via ProcessBuilder (ou Maven Invoker), STDOUT/STDERR separados, aba Problems com parsing de erros do javac clicáveis.

## Fase 2 — Canvas WYSIWYG
- Paleta (containers, controles, formas) com drag-and-drop; movimentação livre, redimensionamento e rotação por bounding box com 8 alças, grid snap, guias inteligentes, multisseleção, agrupar, ordem Z, zoom/pan, undo/redo (Command pattern).
- Modelos de componentes: botões (primário, perigo, contorno, pílula, ícone, toggle, FAB) e labels (título, subtítulo, destaque, badge, link), cada um com variantes de tamanho/estado (normal, hover, pressed, disabled).
- Edição gráfica livre do visual de qualquer componente: preenchimento sólido/gradiente linear e radial, borda, raio, sombra/blur, opacidade, fonte, ícone; salvar como "estilo reutilizável" gerando classes em .css; biblioteca de temas.

## Fase 3 — Vetores
- Retângulo, elipse, polígono/estrela, linha, texto e Caneta Bézier (Path com MoveTo/CubicCurveTo/QuadCurveTo/ClosePath): inserir/remover âncoras, alças simétricas/independentes, converter canto↔suave, fechar caminho, operações booleanas (união, subtração, interseção), SVG import/export (SVGPath).

## Fase 4 — Sincronização
- Modo FXML (Scene Builder): gera/atualiza o .fxml e injeta campos @FXML e stubs de handlers (onAction) no Controller via JavaParser sem perder formatação/comentários.
- Modo Java declarativo (WindowBuilder): grava a construção da UI num método marcado (ex.: // <coffy:generated>) preservando código manual fora dele.
- Bidirecional: edição do código recarrega o Canvas (FXMLLoader para FXML; AST para Java). Geração em thread secundária com debounce; conflitos resolvidos por região gerada.
- Barra lateral de código em tempo real, com destaque da linha correspondente ao nó selecionado (e vice-versa).
- Abas por arquivo: Source Code | Design | Split.

## Fase 5 — Editor e IDE
- RichTextFX: realce Java/XML/CSS, números de linha, dobragem, autocomplete básico (JavaParser symbol solver), formatar, organizar imports, refatorar renomear.
- Run/Debug (JDI), atalhos estilo Eclipse, busca no projeto, Package Explorer + Hierarquia de nós.

## Ideias inovadoras
1. Pré-visualização ao vivo em janela separada (hot reload do FXML).
2. Modo responsivo: simular tamanhos de janela e restrições AnchorPane/GridPane visualmente.
3. Inspetor de acessibilidade (contraste, ordem de tab, textos alternativos).
4. Assistente de IA: descrever a tela em texto e gerar o layout; sugerir nomes de fx:id.
5. Modelos de telas completas (login, dashboard, CRUD com TableView) ligados ao Controller.
6. Binding visual: ligar propriedades a ViewModels sem escrever código.
7. Exportar para jpackage (instalador) com um clique.
8. Controle de versão (Git) integrado e diff visual de FXML.
9. Biblioteca de ícones/emoji (Ikonli) e importação de paletas.
10. Modo "Café": temas e atalhos temáticos (opcional).

## Critérios de aceite
Compila com `mvn verify`; testes JUnit para geradores FXML/Java e para o round-trip código↔canvas; UI nunca bloqueia (>16ms) durante geração; arquivos salvos abrem no Scene Builder oficial.
