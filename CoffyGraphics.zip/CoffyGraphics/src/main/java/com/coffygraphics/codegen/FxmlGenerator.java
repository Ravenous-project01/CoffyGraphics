package com.coffygraphics.codegen;

import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.*;
import java.util.*;

/** Gera FXML (modo Scene Builder) ou Java declarativo (modo WindowBuilder) a partir dos nós do Canvas. */
public class FxmlGenerator {
    public static String toFxml(List<Node> nodes, String controller) {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        Set<String> imports = new TreeSet<>(List.of("javafx.scene.layout.AnchorPane"));
        for (Node n : nodes) imports.add((n instanceof Shape ? "javafx.scene.shape." : "javafx.scene.control.") + n.getClass().getSimpleName());
        imports.forEach(i -> sb.append("<?import ").append(i).append("?>\n"));
        sb.append("\n<AnchorPane xmlns:fx=\"http://javafx.com/fxml\" fx:controller=\"").append(controller).append("\">\n");
        for (Node n : nodes) {
            sb.append("  <").append(n.getClass().getSimpleName()).append(" fx:id=\"").append(n.getId()).append("\"")
              .append(" layoutX=\"").append((int) n.getLayoutX()).append("\" layoutY=\"").append((int) n.getLayoutY()).append("\"");
            if (n instanceof Labeled l) sb.append(" text=\"").append(esc(l.getText())).append("\"");
            if (!(n instanceof Shape) && n.getStyle() != null && !n.getStyle().isEmpty()) sb.append(" style=\"").append(esc(n.getStyle())).append("\"");
            if (n instanceof Path p) {
                sb.append(" stroke=\"").append(hex(p.getStroke())).append("\" strokeWidth=\"").append(f(p.getStrokeWidth())).append("\" fill=\"TRANSPARENT\">\n    <elements>\n");
                for (PathElement e : p.getElements()) sb.append("      ").append(elem(e)).append("\n");
                sb.append("    </elements>\n  </Path>\n"); continue;
            }
            if (n instanceof Rectangle r) sb.append(" width=\"").append((int) r.getWidth()).append("\" height=\"").append((int) r.getHeight()).append("\" fill=\"").append(hex(r.getFill())).append("\"");
            if (n instanceof Ellipse e) sb.append(" radiusX=\"").append((int) e.getRadiusX()).append("\" radiusY=\"").append((int) e.getRadiusY()).append("\"");
            sb.append("/>\n");
        }
        return sb.append("</AnchorPane>\n").toString();
    }

    public static String toJava(List<Node> nodes) {
        StringBuilder sb = new StringBuilder("AnchorPane root = new AnchorPane();\n");
        for (Node n : nodes) {
            String t = n.getClass().getSimpleName(), v = n.getId();
            sb.append(t).append(' ').append(v).append(" = new ").append(t).append("();\n");
            sb.append(v).append(".setLayoutX(").append((int) n.getLayoutX()).append("); ").append(v).append(".setLayoutY(").append((int) n.getLayoutY()).append(");\n");
            if (n instanceof Labeled l) sb.append(v).append(".setText(\"").append(l.getText()).append("\");\n");
            sb.append("root.getChildren().add(").append(v).append(");\n");
        }
        return sb.toString();
    }

    private static String elem(PathElement e) {
        if (e instanceof MoveTo m) return "<MoveTo x=\"" + f(m.getX()) + "\" y=\"" + f(m.getY()) + "\"/>";
        if (e instanceof CubicCurveTo c) return "<CubicCurveTo controlX1=\"" + f(c.getControlX1()) + "\" controlY1=\"" + f(c.getControlY1())
            + "\" controlX2=\"" + f(c.getControlX2()) + "\" controlY2=\"" + f(c.getControlY2()) + "\" x=\"" + f(c.getX()) + "\" y=\"" + f(c.getY()) + "\"/>";
        return "";
    }
    private static String f(double d) { return String.format(Locale.ROOT, "%.1f", d); }
    private static String esc(String s) { return s == null ? "" : s.replace("&", "&amp;").replace("\"", "&quot;").replace("<", "&lt;"); }
    private static String hex(Paint p) { return p instanceof Color c ? String.format("#%02X%02X%02X", (int) (c.getRed() * 255), (int) (c.getGreen() * 255), (int) (c.getBlue() * 255)) : "#000000"; }
}
