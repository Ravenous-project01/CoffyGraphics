package com.coffygraphics;

import com.coffygraphics.core.WorkspaceManager;
import com.coffygraphics.ui.MainWindow;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import java.io.File;

/** Launcher: escolhe o Workspace (ou usa o padrão salvo) e abre a IDE. */
public class Main extends Application {
    @Override public void start(Stage stage) {
        WorkspaceManager ws = new WorkspaceManager();
        File dir = ws.getSavedWorkspace();
        if (dir == null) {
            DirectoryChooser ch = new DirectoryChooser();
            ch.setTitle("CoffyGraphics - escolha o Workspace");
            ch.setInitialDirectory(new File(System.getProperty("user.home")));
            dir = ch.showDialog(stage);
            if (dir == null) { System.exit(0); }
            ws.saveAsDefault(dir);
        }
        ws.setRoot(dir);
        Scene scene = new Scene(new MainWindow(ws), 1400, 850);
        scene.getStylesheets().add(getClass().getResource("coffy.css").toExternalForm());
        stage.setTitle("CoffyGraphics - " + dir.getAbsolutePath());
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] a) { launch(a); }
}
