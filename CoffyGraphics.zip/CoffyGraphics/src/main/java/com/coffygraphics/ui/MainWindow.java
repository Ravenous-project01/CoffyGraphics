package com.coffygraphics.ui;

import com.coffygraphics.codegen.FxmlGenerator;
import com.coffygraphics.core.*;
import com.coffygraphics.design.*;
import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.application.Platform;
import javafx.util.Duration;
import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.LineNumberFactory;
import java.io.File;
import java.util.function.Consumer;

/** Janela principal: Explorer | Paleta+Canvas | Inspetor + Código ao vivo | Console. */
public class MainWindow extends BorderPane {
    private final DesignCanvas canvas = new DesignCanvas();
    private final CodeArea liveCode = new CodeArea();
    private final TextArea console = new TextArea();
    private final TextField fId = new TextField(), fText = new TextField(), fX = new TextField(), fY = new TextField(), fStyle = new TextField();
    private final ToggleButton modeFxml = new ToggleButton("FXML"), modeJava = new ToggleButton("Java");
    private final PauseTransition debounce = new PauseTransition(Duration.millis(150));
    private File currentProject;

    public MainWindow(WorkspaceManager ws) {
        setTop(menu(ws)); setLeft(explorer(ws)); setCenter(center()); setRight(right()); setBottom(bottom());
        debounce.setOnFinished(e -> regen());
        canvas.onChange(debounce::playFromStart);
        canvas.selectedProperty().addListener((o, a, n) -> loadInspector(n));
        wireInspector(); regen();
    }

    private MenuBar menu(WorkspaceManager ws) {
        MenuItem newProj = new MenuItem("Novo Projeto Maven...");
        newProj.setOnAction(e -> {
            TextInputDialog d = new TextInputDialog("meuprojeto"); d.setHeaderText("artifactId (groupId: com.exemplo)");
            d.showAndWait().ifPresent(a -> { try {
                currentProject = ws.createMavenProject("com.exemplo", a, "1.0");
                ws.createWindow(currentProject, "com.exemplo", "Main"); setLeft(explorer(ws));
            } catch (Exception ex) { console.appendText("[ERRO] " + ex + "\n"); } });
        });
        MenuItem compile = new MenuItem("mvn compile"); compile.setOnAction(e -> run("compile"));
        MenuItem exec = new MenuItem("mvn exec:java"); exec.setOnAction(e -> run("exec:java"));
        return new MenuBar(new Menu("File", null, newProj), new Menu("Edit"), new Menu("Source"), new Menu("Refactor"),
            new Menu("Project", null, compile), new Menu("Run", null, exec), new Menu("Help"));
    }
    private void run(String goal) {
        if (currentProject == null) { console.appendText("Selecione um projeto no Explorer.\n"); return; }
        MavenRunner.run(currentProject, s -> Platform.runLater(() -> console.appendText(s + "\n")), goal);
    }

    private Node explorer(WorkspaceManager ws) {
        TreeItem<File> rootItem = new TreeItem<>(ws.getRoot()); rootItem.setExpanded(true);
        for (File p : ws.listMavenProjects()) rootItem.getChildren().add(tree(p));
        TreeView<File> tv = new TreeView<>(rootItem);
        tv.setCellFactory(x -> new TreeCell<>() { @Override protected void updateItem(File f, boolean empty) { super.updateItem(f, empty);
            setText(empty || f == null ? null : (f.isDirectory() ? "📁 " : "📄 ") + f.getName()); } });
        tv.getSelectionModel().selectedItemProperty().addListener((o, a, n) -> { if (n != null) { File f = n.getValue();
            while (f != null && !new File(f, "pom.xml").exists()) f = f.getParentFile(); if (f != null) currentProject = f; } });
        tv.setPrefWidth(230); return tv;
    }
    private TreeItem<File> tree(File f) {
        TreeItem<File> it = new TreeItem<>(f);
        File[] k = f.listFiles(); if (k != null) java.util.Arrays.stream(k).sorted().forEach(c -> it.getChildren().add(tree(c)));
        return it;
    }

    private Node center() {
        VBox palette = new VBox(6); palette.setPadding(new Insets(8)); palette.setPrefWidth(170);
        ComponentFactory.CATALOG.forEach((group, items) -> {
            Label g = new Label(group); g.getStyleClass().add("palette-group"); palette.getChildren().add(g);
            for (String it : items) {
                Label chip = new Label(it.replace(":", " · ")); chip.getStyleClass().add("palette-chip");
                chip.setOnDragDetected(e -> { Dragboard db = chip.startDragAndDrop(TransferMode.COPY);
                    ClipboardContent c = new ClipboardContent(); c.putString(it); db.setContent(c); e.consume(); });
                palette.getChildren().add(chip);
            }
        });
        CheckBox snap = new CheckBox("Grid snap"); snap.setSelected(true); snap.setOnAction(e -> canvas.setSnap(snap.isSelected()));
        palette.getChildren().add(snap);
        canvas.setPrefSize(1400, 1000);
        BorderPane design = new BorderPane(new ScrollPane(canvas)); design.setLeft(new ScrollPane(palette));
        Tab tDesign = new Tab("🎨 Design", design);
        Tab tSrc = new Tab("Source Code", new CodeArea("// editor de código-fonte: em evolução (RichTextFX)"));
        tDesign.setClosable(false); tSrc.setClosable(false);
        return new TabPane(tDesign, tSrc);
    }

    private Node right() {
        GridPane g = new GridPane(); g.setHgap(6); g.setVgap(6); g.setPadding(new Insets(8));
        String[] labels = {"fx:id", "Text", "X", "Y", "style"}; TextField[] fs = {fId, fText, fX, fY, fStyle};
        for (int i = 0; i < labels.length; i++) { g.add(new Label(labels[i]), 0, i); g.add(fs[i], 1, i); }
        ToggleGroup tg = new ToggleGroup(); modeFxml.setToggleGroup(tg); modeJava.setToggleGroup(tg); modeFxml.setSelected(true);
        tg.selectedToggleProperty().addListener((o, a, n) -> { if (n == null) modeFxml.setSelected(true); regen(); });
        g.add(new HBox(4, new Label("Gerar:"), modeFxml, modeJava), 0, labels.length, 2, 1);
        TitledPane insp = new TitledPane("Inspetor de Propriedades", g); insp.setCollapsible(false);
        liveCode.setEditable(false); liveCode.setParagraphGraphicFactory(LineNumberFactory.get(liveCode));
        liveCode.getStyleClass().add("code-area");
        TitledPane code = new TitledPane("Código em tempo real", liveCode); code.setCollapsible(false); code.setMaxHeight(Double.MAX_VALUE);
        VBox box = new VBox(insp, code); VBox.setVgrow(code, Priority.ALWAYS); box.setPrefWidth(380); return box;
    }

    private Node bottom() {
        console.setEditable(false); console.setPrefHeight(140);
        TabPane t = new TabPane(new Tab("Console Output", console), new Tab("Problems"), new Tab("Terminal"));
        t.getTabs().forEach(x -> x.setClosable(false)); return t;
    }

    private void wireInspector() {
        fId.setOnAction(e -> apply(n -> n.setId(fId.getText())));
        fText.setOnAction(e -> apply(n -> { if (n instanceof Labeled l) l.setText(fText.getText()); }));
        fX.setOnAction(e -> apply(n -> n.setLayoutX(parse(fX.getText(), n.getLayoutX()))));
        fY.setOnAction(e -> apply(n -> n.setLayoutY(parse(fY.getText(), n.getLayoutY()))));
        fStyle.setOnAction(e -> apply(n -> n.setStyle(fStyle.getText())));
    }
    private void apply(Consumer<Node> c) { Node n = canvas.selectedProperty().get(); if (n != null) { c.accept(n); canvas.fire(); } }
    private double parse(String s, double d) { try { return Double.parseDouble(s); } catch (Exception e) { return d; } }
    private void loadInspector(Node n) {
        fId.setText(n == null || n.getId() == null ? "" : n.getId());
        fX.setText(n == null ? "" : String.valueOf((int) n.getLayoutX()));
        fY.setText(n == null ? "" : String.valueOf((int) n.getLayoutY()));
        fStyle.setText(n == null || n.getStyle() == null ? "" : n.getStyle());
        fText.setText(n instanceof Labeled l ? l.getText() : "");
    }

    private void regen() {
        var nodes = canvas.designNodes();
        liveCode.replaceText(modeJava.isSelected() ? FxmlGenerator.toJava(nodes)
            : FxmlGenerator.toFxml(nodes, "com.exemplo.MainController"));
    }
}
