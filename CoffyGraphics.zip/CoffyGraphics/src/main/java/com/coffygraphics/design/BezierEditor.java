package com.coffygraphics.design;

import javafx.scene.Node;
import javafx.scene.input.MouseButton;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import java.util.*;

/**
 * Curva Bézier editável (Path com MoveTo + CubicCurveTo).
 * Duplo clique no traçado: adiciona segmento. Arrastar âncoras/alças: ajusta a curva.
 * Clique direito numa âncora: remove o segmento. Alças aparecem enquanto a curva está selecionada.
 */
public class BezierEditor {
    public static Path newCurve() {
        Path p = new Path(new MoveTo(0, 60), new CubicCurveTo(30, 0, 90, 120, 120, 60));
        p.setStroke(Color.web("#92400E")); p.setStrokeWidth(3); p.setFill(Color.TRANSPARENT);
        return p;
    }

    public static void attach(DesignCanvas canvas, Path path, Runnable onChange) {
        List<Node> handles = new ArrayList<>();
        Runnable[] rebuild = new Runnable[1];
        rebuild[0] = () -> {
            canvas.getChildren().removeAll(handles); handles.clear();
            if (canvas.selectedProperty().get() != path) return;
            double ox = path.getLayoutX(), oy = path.getLayoutY();
            MoveTo m0 = (MoveTo) path.getElements().get(0);
            double px = m0.getX(), py = m0.getY();
            handles.add(dot(canvas, ox, oy, m0, 0, path, onChange, rebuild));
            for (int i = 1; i < path.getElements().size(); i++) {
                if (path.getElements().get(i) instanceof CubicCurveTo c) {
                    handles.add(guide(ox + px, oy + py, ox + c.getControlX1(), oy + c.getControlY1()));
                    handles.add(guide(ox + c.getX(), oy + c.getY(), ox + c.getControlX2(), oy + c.getControlY2()));
                    handles.add(dot(canvas, ox, oy, c, 1, path, onChange, rebuild));
                    handles.add(dot(canvas, ox, oy, c, 2, path, onChange, rebuild));
                    handles.add(dot(canvas, ox, oy, c, 0, path, onChange, rebuild));
                    px = c.getX(); py = c.getY();
                }
            }
            canvas.getChildren().addAll(handles);
        };
        canvas.selectedProperty().addListener((o, a, b) -> rebuild[0].run());
        path.layoutXProperty().addListener((o, a, b) -> rebuild[0].run());
        path.layoutYProperty().addListener((o, a, b) -> rebuild[0].run());
        path.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2 && e.getButton() == MouseButton.PRIMARY) {
                CubicCurveTo last = (CubicCurveTo) path.getElements().get(path.getElements().size() - 1);
                double x = last.getX() + 60, y = last.getY();
                path.getElements().add(new CubicCurveTo(last.getX() + 20, last.getY() - 40, x - 20, y + 40, x, y));
                rebuild[0].run(); onChange.run();
            }
        });
    }

    private static Node guide(double x1, double y1, double x2, double y2) {
        Line l = new Line(x1, y1, x2, y2); l.setStroke(Color.web("#3B82F6")); l.setMouseTransparent(true); return l;
    }

    /** kind: 0 = âncora, 1 = controle 1, 2 = controle 2. */
    private static Node dot(DesignCanvas canvas, double ox, double oy, PathElement el, int kind, Path path, Runnable onChange, Runnable[] rebuild) {
        double x, y;
        if (el instanceof MoveTo m) { x = m.getX(); y = m.getY(); }
        else { CubicCurveTo q = (CubicCurveTo) el;
            x = kind == 1 ? q.getControlX1() : kind == 2 ? q.getControlX2() : q.getX();
            y = kind == 1 ? q.getControlY1() : kind == 2 ? q.getControlY2() : q.getY(); }
        Circle d = new Circle(ox + x, oy + y, kind == 0 ? 6 : 4.5, kind == 0 ? Color.WHITE : Color.web("#3B82F6"));
        d.setStroke(Color.web("#3B82F6")); d.setStrokeWidth(2);
        d.setOnMouseDragged(e -> {
            var p = canvas.sceneToLocal(e.getSceneX(), e.getSceneY());
            double nx = p.getX() - ox, ny = p.getY() - oy;
            if (el instanceof MoveTo m) { m.setX(nx); m.setY(ny); }
            else { CubicCurveTo q = (CubicCurveTo) el;
                if (kind == 1) { q.setControlX1(nx); q.setControlY1(ny); }
                else if (kind == 2) { q.setControlX2(nx); q.setControlY2(ny); }
                else { q.setX(nx); q.setY(ny); } }
            d.setCenterX(ox + nx); d.setCenterY(oy + ny); onChange.run(); e.consume();
        });
        d.setOnMouseReleased(e -> rebuild[0].run());
        d.setOnMouseClicked(e -> {
            if (e.getButton() == MouseButton.SECONDARY && el instanceof CubicCurveTo && kind == 0 && path.getElements().size() > 2) {
                path.getElements().remove(el); rebuild[0].run(); onChange.run();
            }
        });
        return d;
    }
}
