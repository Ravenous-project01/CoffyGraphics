package com.coffygraphics.design;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.scene.Node;
import javafx.scene.input.*;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import java.util.*;

/** Canvas WYSIWYG: arrastar da paleta, mover livremente (snap opcional), selecionar, editar curvas. */
public class DesignCanvas extends Pane {
    private final ObjectProperty<Node> selected = new SimpleObjectProperty<>();
    private final Rectangle selBox = new Rectangle();
    private final List<Runnable> listeners = new ArrayList<>();
    private final double grid = 10;
    private boolean snap = true;
    private int idCounter = 1;

    public DesignCanvas() {
        getStyleClass().add("design-canvas");
        selBox.setFill(Color.TRANSPARENT); selBox.setStroke(Color.web("#3B82F6"));
        selBox.getStrokeDashArray().addAll(5.0, 4.0); selBox.setMouseTransparent(true); selBox.setVisible(false);
        getChildren().add(selBox);
        setOnDragOver(e -> { if (e.getDragboard().hasString()) e.acceptTransferModes(TransferMode.COPY); });
        setOnDragDropped(e -> {
            Node n = ComponentFactory.create(e.getDragboard().getString(), "node" + (idCounter++));
            if (n != null) place(n, e.getX(), e.getY());
            e.setDropCompleted(n != null); e.consume();
        });
        setOnMousePressed(e -> { if (e.getTarget() == this) select(null); });
        setOnKeyPressed(e -> { if (e.getCode() == KeyCode.DELETE && selected.get() != null) {
            getChildren().remove(selected.get()); select(null); } });
        setFocusTraversable(true);
    }

    public void place(Node n, double x, double y) {
        n.setLayoutX(snap(x)); n.setLayoutY(snap(y));
        makeDraggable(n);
        getChildren().add(n);
        if (n instanceof Path p) BezierEditor.attach(this, p, this::fire);
        select(n);
    }

    private void makeDraggable(Node n) {
        double[] off = new double[2];
        n.setOnMousePressed(e -> { select(n); requestFocus();
            off[0] = e.getSceneX() - n.getLayoutX(); off[1] = e.getSceneY() - n.getLayoutY(); e.consume(); });
        n.setOnMouseDragged(e -> {
            n.setLayoutX(snap(e.getSceneX() - off[0])); n.setLayoutY(snap(e.getSceneY() - off[1]));
            fire(); e.consume(); });
    }
    private double snap(double v) { return snap ? Math.round(v / grid) * grid : v; }
    public void setSnap(boolean s) { snap = s; }

    public void select(Node n) { selected.set(n); fire(); }
    private void updateSel() {
        Node n = selected.get();
        if (n == null) { selBox.setVisible(false); return; }
        var b = n.getBoundsInParent();
        selBox.setX(b.getMinX() - 2); selBox.setY(b.getMinY() - 2);
        selBox.setWidth(b.getWidth() + 4); selBox.setHeight(b.getHeight() + 4);
        selBox.setVisible(true); selBox.toFront();
    }
    public ObjectProperty<Node> selectedProperty() { return selected; }
    /** Apenas nós de design (exclui caixa de seleção e alças de edição, que não têm id). */
    public List<Node> designNodes() {
        List<Node> l = new ArrayList<>();
        for (Node n : getChildren()) if (n.getId() != null) l.add(n);
        return l;
    }
    public void onChange(Runnable r) { listeners.add(r); }
    public void fire() { updateSel(); listeners.forEach(Runnable::run); }
}
