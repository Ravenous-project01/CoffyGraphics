package com.coffygraphics.design;

import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import java.util.*;

/** Catálogo de componentes + modelos (templates) de botões e labels com visuais prontos. */
public class ComponentFactory {
    public static final LinkedHashMap<String, List<String>> CATALOG = new LinkedHashMap<>();
    static {
        CATALOG.put("Controles", List.of("Button", "Label", "TextField", "CheckBox", "TableView"));
        CATALOG.put("Modelos de Botão", List.of("Button:Primário", "Button:Perigo", "Button:Contorno", "Button:Pílula"));
        CATALOG.put("Modelos de Label", List.of("Label:Título", "Label:Subtítulo", "Label:Destaque"));
        CATALOG.put("Formas", List.of("Rectangle", "Ellipse", "Polygon", "Curve"));
    }

    public static Node create(String type, String id) {
        String base = type.contains(":") ? type.split(":")[0] : type;
        String tpl = type.contains(":") ? type.split(":")[1] : "";
        Node n = switch (base) {
            case "Button" -> template(new Button(tpl.isEmpty() ? "Button" : tpl), tpl);
            case "Label" -> template(new Label(tpl.isEmpty() ? "Label" : tpl), tpl);
            case "TextField" -> new TextField();
            case "CheckBox" -> new CheckBox("CheckBox");
            case "TableView" -> { TableView<Object> t = new TableView<>(); t.setPrefSize(300, 180); yield t; }
            case "Rectangle" -> new Rectangle(120, 80, Color.web("#60A5FA"));
            case "Ellipse" -> new Ellipse(60, 40);
            case "Polygon" -> new Polygon(0, 60, 40, 0, 80, 60);
            case "Curve" -> BezierEditor.newCurve();
            default -> null;
        };
        if (n instanceof Shape s && !(n instanceof Path)) s.setFill(Color.web("#F59E0B"));
        if (n instanceof Rectangle r) r.setFill(Color.web("#60A5FA"));
        if (n != null) n.setId(id);
        return n;
    }

    private static Node template(Control c, String tpl) {
        c.setStyle(switch (tpl) {
            case "Primário" -> "-fx-background-color:#3B82F6;-fx-text-fill:white;-fx-background-radius:6;-fx-font-weight:bold;";
            case "Perigo" -> "-fx-background-color:#EF4444;-fx-text-fill:white;-fx-background-radius:6;";
            case "Contorno" -> "-fx-background-color:transparent;-fx-border-color:#3B82F6;-fx-text-fill:#3B82F6;-fx-border-radius:6;";
            case "Pílula" -> "-fx-background-color:#8B5E3C;-fx-text-fill:white;-fx-background-radius:999;-fx-padding:6 18;";
            case "Título" -> "-fx-font-size:28;-fx-font-weight:bold;-fx-text-fill:#3E2723;";
            case "Subtítulo" -> "-fx-font-size:16;-fx-text-fill:#6D4C41;";
            case "Destaque" -> "-fx-background-color:#FEF3C7;-fx-padding:4 10;-fx-background-radius:4;-fx-text-fill:#92400E;";
            default -> "";
        });
        return c;
    }
}
