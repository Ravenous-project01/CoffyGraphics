package com.coffygraphics.core;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;

/** Executa metas Maven via ProcessBuilder e envia a saída ao console da IDE. */
public class MavenRunner {
    public static void run(File project, Consumer<String> log, String... goals) {
        Thread t = new Thread(() -> {
            try {
                String mvn = System.getProperty("os.name").toLowerCase().contains("win") ? "mvn.cmd" : "mvn";
                List<String> cmd = new ArrayList<>(); cmd.add(mvn); cmd.addAll(Arrays.asList(goals));
                Process p = new ProcessBuilder(cmd).directory(project).redirectErrorStream(true).start();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                    String line; while ((line = r.readLine()) != null) log.accept(line);
                }
                log.accept("[exit " + p.waitFor() + "]");
            } catch (Exception e) { log.accept("[ERRO] " + e.getMessage()); }
        }, "maven-runner");
        t.setDaemon(true); t.start();
    }
}
