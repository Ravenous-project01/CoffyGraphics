package com.coffygraphics.core;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.prefs.Preferences;

/** Gerencia o Workspace: lista projetos Maven e cria novos (pom + estrutura padrão). */
public class WorkspaceManager {
    private static final String KEY = "defaultWorkspace";
    private final Preferences prefs = Preferences.userNodeForPackage(WorkspaceManager.class);
    private File root;

    public File getSavedWorkspace() {
        String p = prefs.get(KEY, null);
        return (p != null && new File(p).isDirectory()) ? new File(p) : null;
    }
    public void saveAsDefault(File dir) { prefs.put(KEY, dir.getAbsolutePath()); }
    public void setRoot(File r) { this.root = r; }
    public File getRoot() { return root; }

    public List<File> listMavenProjects() {
        List<File> out = new ArrayList<>();
        File[] kids = root.listFiles(File::isDirectory);
        if (kids != null) for (File k : kids) if (new File(k, "pom.xml").exists()) out.add(k);
        return out;
    }

    public File createMavenProject(String groupId, String artifactId, String version) throws IOException {
        Path base = root.toPath().resolve(artifactId);
        Files.createDirectories(base.resolve("src/main/java/" + groupId.replace('.', '/')));
        Files.createDirectories(base.resolve("src/main/resources"));
        Files.createDirectories(base.resolve("src/test/java"));
        String pom = """
            <?xml version="1.0" encoding="UTF-8"?>
            <project xmlns="http://maven.apache.org/POM/4.0.0">
              <modelVersion>4.0.0</modelVersion>
              <groupId>%s</groupId><artifactId>%s</artifactId><version>%s</version>
              <properties><maven.compiler.release>17</maven.compiler.release>
                <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding></properties>
              <dependencies>
                <dependency><groupId>org.openjfx</groupId><artifactId>javafx-controls</artifactId><version>21.0.2</version></dependency>
                <dependency><groupId>org.openjfx</groupId><artifactId>javafx-fxml</artifactId><version>21.0.2</version></dependency>
                <dependency><groupId>org.junit.jupiter</groupId><artifactId>junit-jupiter</artifactId><version>5.10.2</version><scope>test</scope></dependency>
              </dependencies>
            </project>
            """.formatted(groupId, artifactId, version);
        Files.writeString(base.resolve("pom.xml"), pom);
        return base.toFile();
    }

    /** Novo FXML + Controller pareados. */
    public void createWindow(File project, String pkg, String name) throws IOException {
        Path java = project.toPath().resolve("src/main/java/" + pkg.replace('.', '/'));
        Path res = project.toPath().resolve("src/main/resources/" + pkg.replace('.', '/'));
        Files.createDirectories(java); Files.createDirectories(res);
        Files.writeString(res.resolve(name + ".fxml"), """
            <?xml version="1.0" encoding="UTF-8"?>
            <?import javafx.scene.layout.AnchorPane?>
            <AnchorPane xmlns:fx="http://javafx.com/fxml" fx:controller="%s.%sController" prefWidth="600" prefHeight="400"/>
            """.formatted(pkg, name));
        Files.writeString(java.resolve(name + "Controller.java"),
            "package " + pkg + ";\n\npublic class " + name + "Controller {\n}\n");
    }
}
